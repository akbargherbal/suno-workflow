#!/usr/bin/env python3
"""
Benchmark: Demucs (baseline) vs audio-separator / BS-Roformer
for vocals / instrumental stem separation.

Designed for Google Colab with a T4 GPU runtime.

Usage:
    python benchmark_separators.py ./audio_data -o ./benchmark_results
    python benchmark_separators.py ./audio_data --skip demucs   # re-run only one method
"""

import argparse
import gc
import json
import subprocess
import sys
import time
from pathlib import Path

import torch
import soundfile as sf

SUPPORTED_EXTENSIONS = {".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg", ".opus"}


def get_audio_duration(path: Path) -> float:
    info = sf.info(str(path))
    return info.frames / info.samplerate


def reset_gpu_stats() -> None:
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()


def gpu_peak_mb() -> float:
    if torch.cuda.is_available():
        return torch.cuda.max_memory_allocated() / (1024 ** 2)
    return 0.0


def bench_demucs(audio_files, output_dir: Path, model: str = "htdemucs"):
    """
    Times Demucs 2-stem (vocals / no_vocals) separation per file.
    Uses the `demucs` CLI via subprocess since that's the supported entrypoint.
    """
    results = []
    demucs_out = output_dir / "demucs"
    demucs_out.mkdir(parents=True, exist_ok=True)

    # Warm-up run: downloads + loads model weights once so that cost isn't
    # charged to the first timed file. Output is discarded.
    warmup_cmd = [
        sys.executable, "-m", "demucs", "-n", model, "--two-stems", "vocals",
        "-o", str(demucs_out / "_warmup"), str(audio_files[0]),
    ]
    reset_gpu_stats()
    t0 = time.time()
    subprocess.run(warmup_cmd, check=True, capture_output=True)
    load_time = time.time() - t0
    print(f"[demucs] warmup / model load: {load_time:.1f}s")

    for f in audio_files:
        duration = get_audio_duration(f)
        reset_gpu_stats()
        cmd = [
            sys.executable, "-m", "demucs", "-n", model, "--two-stems", "vocals",
            "-o", str(demucs_out), str(f),
        ]
        t0 = time.time()
        subprocess.run(cmd, check=True, capture_output=True)
        elapsed = time.time() - t0
        results.append({
            "method": "demucs",
            "file": f.name,
            "audio_duration_s": round(duration, 2),
            "elapsed_s": round(elapsed, 2),
            "rtf": round(duration / elapsed, 3) if elapsed else None,
            "peak_gpu_mb": round(gpu_peak_mb(), 1),
        })
        print(f"[demucs] {f.name}: {elapsed:.1f}s (RTF {duration / elapsed:.2f}x)")

    return results, load_time


def bench_audio_separator(
    audio_files,
    output_dir: Path,
    model_filename: str = "model_bs_roformer_ep_317_sdr_12.9755.ckpt",
):
    """Times audio-separator (BS-Roformer), matching separate_stems.py's config."""
    from audio_separator.separator import Separator

    as_out = output_dir / "audio_separator"
    as_out.mkdir(parents=True, exist_ok=True)

    separator = Separator(output_format="MP3", output_bitrate="320k", log_level=40)

    reset_gpu_stats()
    t0 = time.time()
    separator.load_model(model_filename=model_filename)
    load_time = time.time() - t0
    print(f"[audio-separator] model load: {load_time:.1f}s")

    results = []
    for f in audio_files:
        duration = get_audio_duration(f)
        song_dir = as_out / f.stem
        song_dir.mkdir(parents=True, exist_ok=True)

        # audio_separator caches output_dir on the loaded model_instance at
        # load_model() time, so sync it explicitly per file (see separate_stems.py).
        separator.output_dir = str(song_dir)
        if separator.model_instance is not None:
            separator.model_instance.output_dir = str(song_dir)

        reset_gpu_stats()
        t0 = time.time()
        separator.separate(
            audio_file_path=str(f),
            custom_output_names={
                "Vocals": f"{f.stem}-Vocals",
                "Instrumental": f"{f.stem}-Instrumental",
            },
        )
        elapsed = time.time() - t0
        results.append({
            "method": "audio-separator (BS-Roformer)",
            "file": f.name,
            "audio_duration_s": round(duration, 2),
            "elapsed_s": round(elapsed, 2),
            "rtf": round(duration / elapsed, 3) if elapsed else None,
            "peak_gpu_mb": round(gpu_peak_mb(), 1),
        })
        print(f"[audio-separator] {f.name}: {elapsed:.1f}s (RTF {duration / elapsed:.2f}x)")

    return results, load_time


def summarize(all_results, load_times):
    import pandas as pd

    df = pd.DataFrame(all_results)

    print("\n" + "=" * 60)
    print("PER-FILE RESULTS")
    print("=" * 60)
    print(df.to_string(index=False))

    summary = df.groupby("method").agg(
        files=("file", "count"),
        avg_elapsed_s=("elapsed_s", "mean"),
        avg_rtf=("rtf", "mean"),
        avg_peak_gpu_mb=("peak_gpu_mb", "mean"),
    ).round(2)
    summary["model_load_s"] = [load_times.get(m, None) for m in summary.index]

    print("\n" + "=" * 60)
    print("SUMMARY BY METHOD")
    print("=" * 60)
    print(summary.to_string())

    return df, summary


def main():
    parser = argparse.ArgumentParser(
        description="Benchmark Demucs vs audio-separator (BS-Roformer) for stem separation."
    )
    parser.add_argument("input_dir", type=str, help="Directory of audio files to benchmark.")
    parser.add_argument("-o", "--output_dir", type=str, default="./benchmark_results")
    parser.add_argument("--demucs_model", type=str, default="htdemucs")
    parser.add_argument(
        "--roformer_model", type=str, default="model_bs_roformer_ep_317_sdr_12.9755.ckpt"
    )
    parser.add_argument(
        "--skip", choices=["none", "demucs", "audio-separator"], default="none",
        help="Skip one method, e.g. if it was already benchmarked in a prior run.",
    )
    args = parser.parse_args()

    input_dir = Path(args.input_dir).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    audio_files = sorted(
        [f for f in input_dir.glob("*") if f.suffix.lower() in SUPPORTED_EXTENSIONS],
        key=lambda p: p.name.lower(),
    )
    if not audio_files:
        raise SystemExit(f"No supported audio files found in {input_dir}")
    print(f"Benchmarking on {len(audio_files)} file(s) from {input_dir}\n")

    all_results = []
    load_times = {}

    if args.skip != "demucs":
        demucs_results, demucs_load = bench_demucs(audio_files, output_dir, model=args.demucs_model)
        all_results += demucs_results
        load_times["demucs"] = round(demucs_load, 2)
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    if args.skip != "audio-separator":
        as_results, as_load = bench_audio_separator(
            audio_files, output_dir, model_filename=args.roformer_model
        )
        all_results += as_results
        load_times["audio-separator (BS-Roformer)"] = round(as_load, 2)

    df, summary = summarize(all_results, load_times)

    df.to_csv(output_dir / "benchmark_per_file.csv", index=False)
    summary.to_csv(output_dir / "benchmark_summary.csv")
    with open(output_dir / "benchmark_raw.json", "w") as fh:
        json.dump(all_results, fh, indent=2, ensure_ascii=False)

    print(f"\nSaved results to {output_dir}")


if __name__ == "__main__":
    main()
