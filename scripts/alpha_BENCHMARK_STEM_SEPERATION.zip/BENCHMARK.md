# Stem Separation Benchmark: Demucs vs. audio-separator (BS-Roformer)

Compares two vocals/instrumental separation approaches on Google Colab (T4 GPU):

| | Baseline | Candidate |
|---|---|---|
| Tool | [Demucs](https://github.com/facebookresearch/demucs) | [audio-separator](https://github.com/nomadkaraoke/python-audio-separator) |
| Model | `htdemucs` (2-stem: `--two-stems vocals`) | `model_bs_roformer_ep_317_sdr_12.9755.ckpt` |
| Script | CLI (`python -m demucs`) | `separate_stems.py` logic, reused directly |

## What it measures

For every audio file, both methods separate the same track into **vocals** and
**instrumental**, and the script records:

- **`elapsed_s`** — wall-clock separation time (model already loaded)
- **`audio_duration_s`** — length of the source track
- **`rtf`** — real-time factor, `audio_duration_s / elapsed_s`. Higher is faster
  (an RTF of 3x means 1 minute of processing per 3 minutes of audio)
- **`peak_gpu_mb`** — peak GPU memory allocated during that file's separation
- Model **load time** (measured once per method, outside the per-file loop, so
  it doesn't skew per-file speed numbers)

Quality (SDR) isn't computed automatically — that needs studio-quality
reference stems to compare against (e.g. MUSDB18), which most personal audio
libraries don't have. The script separates every file with both tools so you
can **A/B listen** to the outputs under `benchmark_results/demucs/` and
`benchmark_results/audio_separator/`.

## Setup (Colab, T4 runtime)

```python
# Baseline
!pip install -q demucs

# Candidate (CUDA 12-compatible build, per separate_stems.py notes)
!pip install -q "audio-separator[gpu]"
!pip uninstall -y onnxruntime-gpu onnxruntime
!pip install -q "audio-separator" "onnxruntime-gpu<1.27.0"

!pip install -q soundfile pandas
```

Make sure **Runtime → Change runtime type → T4 GPU** is selected before installing.

## Running it

```bash
python benchmark_separators.py ./audio_data -o ./benchmark_results
```

Options:

| Flag | Default | Purpose |
|---|---|---|
| `-o / --output_dir` | `./benchmark_results` | Where separated stems + result files go |
| `--demucs_model` | `htdemucs` | Swap in `htdemucs_ft` / `mdx_extra` etc. for other Demucs variants |
| `--roformer_model` | `model_bs_roformer_ep_317_sdr_12.9755.ckpt` | Any model supported by `audio-separator` |
| `--skip {demucs,audio-separator}` | `none` | Re-run just one method without repeating the other |

## Output

- `benchmark_per_file.csv` — one row per (method, file)
- `benchmark_summary.csv` — averaged `elapsed_s`, `rtf`, `peak_gpu_mb`, and model load time per method
- `benchmark_raw.json` — same data as JSON
- Separated audio under `demucs/` and `audio_separator/`, so both can be listened to side by side

## Reading the results

- **Speed**: compare `avg_rtf` — this is the "how much faster is the candidate"
  number. Roughly matches what was already observed in `Stem_Separator.md`
  (~2.97s/it Roformer chunks, ~2 min for a ~4.5 min song → RTF ≈ 2.2–2.5x on a T4).
- **Model load overhead**: Roformer's small load time (a few seconds) matters
  more on short files or when processing many small clips in one session;
  Demucs' load time is dominated by first-time weight download, which is a
  one-off cost.
- **GPU memory**: useful if you plan to batch multiple files concurrently or
  hit T4's 16 GB limit.
- **Quality**: not scored automatically — spot-check a few tracks from each
  output folder for bleed-through, artifacts, or muddiness in the instrumental.
