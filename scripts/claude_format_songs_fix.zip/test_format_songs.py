import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).parent
SCRIPT = HERE / "format_songs.py"
GOLDEN = HERE / "golden"

sys.path.insert(0, str(HERE))
from format_songs import format_batch  # noqa: E402


def song(**kw):
    base = {"name": "n", "style": "s", "lyrics": "l"}
    base.update(kw)
    return base


def run_cli(raw, *args):
    with tempfile.TemporaryDirectory() as d:
        src, out = Path(d) / "in.json", Path(d) / "out.json"
        src.write_text(json.dumps(raw, ensure_ascii=False), encoding="utf-8")
        p = subprocess.run(
            [sys.executable, str(SCRIPT), str(src), "-o", str(out), *args],
            capture_output=True, text=True,
        )
        data = out.read_text(encoding="utf-8") if out.exists() else None
        return p, data


class GoldenRegression(unittest.TestCase):
    """Old inputs and flags must give byte-identical output."""

    def test_golden_files(self):
        for name in ("in_basic", "in_extras", "in_formatted"):
            for tag, extra in (("r1", []), ("r2", ["--repeat", "2"])):
                with self.subTest(name=name, tag=tag):
                    out = HERE / f"_out_{name}_{tag}.json"
                    subprocess.run(
                        [sys.executable, str(SCRIPT), str(HERE / f"{name}.json"),
                         "-o", str(out), *extra],
                        check=True, capture_output=True,
                    )
                    try:
                        self.assertEqual(
                            out.read_bytes(),
                            (GOLDEN / f"{name}.{tag}.json").read_bytes(),
                        )
                    finally:
                        out.unlink(missing_ok=True)


class Seeds(unittest.TestCase):
    def test_no_seed_means_no_key(self):
        r = format_batch([song()])
        self.assertNotIn("seed", r["songs"][0])
        self.assertNotIn("seed", r["defaults"])

    def test_seed_zero_survives(self):
        r = format_batch([song(seed=0)])
        self.assertEqual(r["songs"][0]["seed"], 0)

    def test_key_order(self):
        r = format_batch([{"lyrics": "l", "seed": 1, "style": "s", "name": "n"}])
        self.assertEqual(list(r["songs"][0]), ["name", "style", "lyrics", "seed"])

    def test_bad_seed_types(self):
        for bad in ("5", 1.5, True, None, [1]):
            with self.subTest(bad=bad), self.assertRaises(ValueError) as cm:
                format_batch([song(), song(seed=bad)])
            self.assertEqual(str(cm.exception), "Song #2: 'seed' must be an integer.")

    def test_global_seed_fills_songs_not_defaults(self):
        r = format_batch([song(), song(seed=5), song(seed=0)], seed=7)
        self.assertEqual(r["defaults"], {"repeat": 1})
        self.assertEqual([s["seed"] for s in r["songs"]], [7, 5, 0])

    def test_seed_zero_as_global(self):
        r = format_batch([song()], seed=0)
        self.assertEqual(r["songs"][0]["seed"], 0)

    def test_derive_seeds(self):
        r = format_batch(
            [song(), song(seed=100), song(), song(seed=0)],
            seed=10, derive_seeds=True,
        )
        self.assertEqual([s["seed"] for s in r["songs"]], [10, 100, 12, 0])

    def test_derive_requires_seed(self):
        with self.assertRaises(ValueError):
            format_batch([song()], derive_seeds=True)

    def test_bad_global_seed(self):
        with self.assertRaises(ValueError) as cm:
            format_batch([song()], seed="x")
        self.assertEqual(str(cm.exception), "Seed must be an integer.")

    def test_seed_in_defaults_rejected_with_hint(self):
        with self.assertRaises(ValueError) as cm:
            format_batch([song()], defaults={"seed": 1})
        self.assertIn("Unknown default key(s): seed", str(cm.exception))
        self.assertIn("use --seed", str(cm.exception))


class Defaults(unittest.TestCase):
    def test_unknown_default_rejected(self):
        with self.assertRaises(ValueError) as cm:
            format_batch([song()], defaults={"temperature": 0.8})
        self.assertIn("allowed: lora, quantile, repeat, style, style_file", str(cm.exception))

    def test_allowed_keys_pass(self):
        d = {"lora": "x", "quantile": 0.95, "style": "s", "style_file": "f.txt"}
        r = format_batch([song()], defaults=d)
        self.assertEqual(r["defaults"], {"repeat": 1, **d})

    def test_bad_repeat(self):
        with self.assertRaises(ValueError) as cm:
            format_batch([song()], defaults={"repeat": "2"})
        self.assertEqual(str(cm.exception), "Default 'repeat' must be an integer.")


class ExtraKeys(unittest.TestCase):
    def test_dropped_by_default_with_warning(self):
        msgs = []
        r = format_batch([song(foo=1), song(bar=2, foo=3)], warn=msgs.append)
        self.assertEqual(list(r["songs"][0]), ["name", "style", "lyrics"])
        self.assertEqual(len(msgs), 1)
        self.assertIn("foo, bar", msgs[0])

    def test_no_warning_when_clean(self):
        msgs = []
        format_batch([song(seed=1)], warn=msgs.append)
        self.assertEqual(msgs, [])

    def test_keep_extra_order(self):
        r = format_batch([{"zeta": 1, "seed": 3, "alpha": 2, **song()}], keep_extra=True)
        self.assertEqual(
            list(r["songs"][0]), ["name", "style", "lyrics", "seed", "zeta", "alpha"]
        )


class Errors(unittest.TestCase):
    def test_original_messages_unchanged(self):
        cases = [
            ("x", "Input must be a JSON list of song objects."),
            ([1], "Song #1 is not an object."),
            ([{"name": "n"}], "Song #1 is missing keys: style, lyrics"),
        ]
        for raw, msg in cases:
            with self.subTest(raw=raw), self.assertRaises(ValueError) as cm:
                format_batch(raw)
            self.assertEqual(str(cm.exception), msg)


class RealBatch(unittest.TestCase):
    def test_batch_05_is_idempotent(self):
        src = HERE / "batch_05_formatted.json"
        with tempfile.TemporaryDirectory() as d:
            out = Path(d) / "o.json"
            subprocess.run([sys.executable, str(SCRIPT), str(src), "-o", str(out)],
                           check=True, capture_output=True)
            # Compare parsed JSON: the uploaded file has CRLF line endings.
            self.assertEqual(
                json.loads(out.read_text(encoding="utf-8")),
                json.loads(src.read_text(encoding="utf-8")),
            )


class CLI(unittest.TestCase):
    def test_default_run_has_no_seed_and_quiet_stderr(self):
        p, data = run_cli([song()])
        self.assertEqual(p.returncode, 0)
        self.assertEqual(p.stderr, "")
        self.assertNotIn("seed", data)

    def test_seed_zero_flag(self):
        p, data = run_cli([song()], "--seed", "0")
        out = json.loads(data)
        self.assertEqual(out["songs"][0]["seed"], 0)
        self.assertEqual(out["defaults"], {"repeat": 1})

    def test_seed_flag_never_pollutes_defaults(self):
        _, data = run_cli([song(), song()], "--seed", "5", "--derive-seeds")
        out = json.loads(data)
        self.assertEqual(out["defaults"], {"repeat": 1})
        self.assertEqual([s["seed"] for s in out["songs"]], [5, 6])

    def test_default_seed_flag_rejected(self):
        p, data = run_cli([song()], "--default", "seed=3")
        self.assertEqual(p.returncode, 1)
        self.assertIn("Seeds are per-song only", p.stderr)
        self.assertIsNone(data)

    def test_output_defaults_always_allowed(self):
        allowed = {"lora", "quantile", "repeat", "style", "style_file"}
        _, data = run_cli([song(seed=1)], "--seed", "9", "-d", "quantile=0.9")
        self.assertLessEqual(set(json.loads(data)["defaults"]), allowed)

    def test_explicit_repeat_one_beats_file(self):
        with tempfile.TemporaryDirectory() as d:
            df = Path(d) / "d.json"
            df.write_text('{"repeat": 5, "quantile": 0.9}')
            _, data = run_cli([song()], "--defaults-file", str(df))
            self.assertEqual(json.loads(data)["defaults"], {"repeat": 5, "quantile": 0.9})
            _, data = run_cli([song()], "--defaults-file", str(df), "--repeat", "1")
            self.assertEqual(json.loads(data)["defaults"], {"repeat": 1, "quantile": 0.9})

    def test_precedence_chain(self):
        raw = {"defaults": {"repeat": 9, "quantile": 0.1, "style": "in"}, "songs": [song()]}
        with tempfile.TemporaryDirectory() as d:
            df = Path(d) / "d.json"
            df.write_text('{"quantile": 0.2, "style": "file"}')
            _, data = run_cli(
                raw, "--keep-input-defaults", "--defaults-file", str(df),
                "--default", "style=cli", "--default", "quantile=0.3", "--repeat", "4",
            )
        self.assertEqual(
            json.loads(data)["defaults"], {"repeat": 4, "quantile": 0.3, "style": "cli"}
        )

    def test_input_defaults_reset_unless_asked(self):
        raw = {"defaults": {"repeat": 9}, "songs": [song()]}
        _, data = run_cli(raw)
        self.assertEqual(json.loads(data)["defaults"], {"repeat": 1})
        _, data = run_cli(raw, "--keep-input-defaults")
        self.assertEqual(json.loads(data)["defaults"], {"repeat": 9})

    def test_default_value_parsing(self):
        _, data = run_cli([song()], "-d", "quantile=0.8", "-d", "style=hello", "-d", "lora=null")
        self.assertEqual(
            json.loads(data)["defaults"],
            {"repeat": 1, "quantile": 0.8, "style": "hello", "lora": None},
        )

    def test_bad_default_and_derive_errors(self):
        p, _ = run_cli([song()], "--default", "novalue")
        self.assertNotEqual(p.returncode, 0)
        p, _ = run_cli([song()], "--derive-seeds")
        self.assertEqual(p.returncode, 1)
        self.assertIn("Error:", p.stderr)

    def test_arabic_not_escaped(self):
        _, data = run_cli([song(name="أغنية")], "--seed", "1")
        self.assertIn("أغنية", data)


if __name__ == "__main__":
    unittest.main()
