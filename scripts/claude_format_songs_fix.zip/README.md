# format_songs.py

Reformats a raw song batch into the standard batch format.

```
python format_songs.py batch_01.json [-o out.json] [options]
```

## Input

A JSON list of objects (or an already-formatted file).

| Key      | Required | Notes                                            |
|----------|----------|--------------------------------------------------|
| `name`   | yes      |                                                  |
| `style`  | yes      |                                                  |
| `lyrics` | yes      |                                                  |
| `seed`   | no       | Integer. Emitted only if present (`0` is valid). |

Unknown song keys are dropped with a stderr warning, unless `--keep-extra` is
used (they are then appended after the known keys, in input order).

## Output

```json
{"defaults": {"repeat": 1}, "songs": [{"name": "...", "style": "...", "lyrics": "...", "seed": 1}]}
```

Key order per song: required, optional, extras.

## Seeds are per-song only

The generator rejects `seed` inside `defaults`, so this script never writes it
there (and rejects it in any defaults source, with a hint).

| Flag | Effect |
|------|--------|
| `--seed N` | Writes seed `N` on every song that has no seed of its own |
| `--seed N --derive-seeds` | Song at 0-based position `n` gets `N + n` |

A song's own seed always wins.

## Defaults

Allowed keys (matching the generator): `lora`, `quantile`, `repeat`, `style`,
`style_file`. Anything else is an error at format time.

| Flag | Effect |
|------|--------|
| `-r, --repeat N` | `defaults.repeat` (default 1) |
| `-d, --default KEY=VALUE` | Set an allowed defaults key; value parsed as JSON if possible. Repeatable |
| `--defaults-file FILE` | JSON object merged into defaults |
| `--keep-input-defaults` | Keep `defaults` of an already-formatted input (otherwise reset, as before) |

Precedence, lowest to highest: built-in (`repeat=1`), input file's defaults
(with `--keep-input-defaults`), `--defaults-file`, `--default`, `--repeat`.

## Adding things later

- New optional per-song key: add one line to `FIELD_SPECS`.
- New key the generator accepts in defaults: add it to `ALLOWED_DEFAULT_KEYS`.

## Tests

```
python -m unittest -v
```

Includes golden-file checks proving old inputs produce byte-identical output.
